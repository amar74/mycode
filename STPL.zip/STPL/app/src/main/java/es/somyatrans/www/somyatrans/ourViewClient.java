package es.somyatrans.www.somyatrans;

import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Created by amarn on 1/22/2019.
 */

class ourViewClient extends WebViewClient {
        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;

        }
}
