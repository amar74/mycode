package es.somyatrans.www.somyatrans;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

/**
 * Created by amarn on 1/22/2019.
 */

public class somyatrans extends Activity {



    WebView browserWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_somyatrans);
        browserWindow = (WebView) findViewById(R.id.webview);
        WebView myWebView = (WebView) findViewById(R.id.webview);
        myWebView.loadUrl("http://somyatrans.es/");
        myWebView.getSettings().setJavaScriptEnabled(true);

        browserWindow.setWebViewClient(new ourViewClient());


        WebSettings webSettings = browserWindow.getSettings();
        webSettings.setJavaScriptEnabled(true);

         }
    }
